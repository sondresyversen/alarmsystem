#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>
#include <Arduino_NetworkConfigurator.h>
#include "configuratorAgents/agents/BLEAgent.h"
#include "configuratorAgents/agents/SerialAgent.h"
void onActivateAlarmChange();
void onAlarmActiveChange();
void onManualTriggeredChange();
void onResetAlarmChange();

bool activateAlarm;
bool alarmActive;
bool manualTriggered;
bool resetAlarm;

KVStore kvStore;
BLEAgentClass BLEAgent;
SerialAgentClass SerialAgent;
WiFiConnectionHandler ArduinoIoTPreferredConnection; 
NetworkConfiguratorClass NetworkConfigurator(ArduinoIoTPreferredConnection);

void initProperties(){
  NetworkConfigurator.addAgent(BLEAgent);
  NetworkConfigurator.addAgent(SerialAgent);
  NetworkConfigurator.setStorage(kvStore);
  // For changing the default reset pin uncomment and set your preferred pin. Use DISABLE_PIN for disabling the reset procedure.
  //NetworkConfigurator.setReconfigurePin(your_pin);
  ArduinoCloud.setConfigurator(NetworkConfigurator);

  ArduinoCloud.addProperty(activateAlarm, READWRITE, ON_CHANGE, onActivateAlarmChange);
  ArduinoCloud.addProperty(alarmActive, READWRITE, ON_CHANGE, onAlarmActiveChange);
  ArduinoCloud.addProperty(manualTriggered, READWRITE, ON_CHANGE, onManualTriggeredChange);
  ArduinoCloud.addProperty(resetAlarm, READWRITE, ON_CHANGE, onResetAlarmChange);

}
